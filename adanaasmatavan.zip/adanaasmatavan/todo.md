# Adana Asma Tavan Web Sitesi - TODO

## Ana Özellikler

- [x] Responsive navbar ve header tasarımı
- [x] Hero bölümü (banner, başlık, CTA butonları)
- [x] Hakkımızda bölümü (firma tanıtımı, istatistikler)
- [x] Hizmetlerimiz bölümü (asma tavan, karo pan, alçı pan, su tesisat, inşaat malzemeleri)
- [x] Çalışma süreci bölümü (3 adım: analiz, tasarım, uygulama)
- [x] Neden Biz bölümü (4 avantaj)
- [x] Müşteri yorumları/testimonials bölümü
- [x] Galeri sayfası (tamamlanan projeler)
- [x] Hizmetlerimiz sayfası (detaylı hizmet açıklamaları)
- [x] Hakkımızda sayfası (firma hakkında detaylı bilgi)
- [x] İletişim sayfası (form ve iletişim bilgileri)
- [x] Footer (iletişim bilgileri, sosyal medya, telif hakkı)

## Tasarım ve Stil

- [x] Renk paleti belirleme ve CSS değişkenleri ayarlama
- [x] Tipografi seçimi (Google Fonts entegrasyonu)
- [x] Responsive tasarım (mobile, tablet, desktop)
- [x] Tailwind CSS ve shadcn/ui bileşenleri kullanımı

## İçerik ve Görseller

- [x] Hero görseli hazırlama
- [x] Hizmet görselleri hazırlama
- [x] Galeri görselleri hazırlama
- [ ] Logo tasarımı/hazırlama
- [x] İçerik yazıları ve açıklamalar

## İletişim Formu

- [x] İletişim formu tasarımı
- [x] Form validasyonu
- [x] Form gönderimi (e-mail veya webhook)

## SEO ve Performans

- [ ] Meta tags ayarlama (title, description, keywords)
- [ ] robots.txt ve sitemap.xml
- [ ] Resim optimizasyonu
- [ ] Sayfa yükleme performansı kontrol

## Test ve Yayın

- [x] Tüm sayfaları tarayıcıda test etme
- [x] Responsive tasarım testi
- [x] Form testleri
- [ ] Checkpoint oluşturma
- [ ] Siteyi yayınlama
