import { Hammer, Droplet, Wrench, Package, Lightbulb, ArrowRight } from 'lucide-react';

export default function ServicesPage() {
  const services = [
    {
      number: '01',
      icon: Lightbulb,
      title: 'Asma Tavan Sistemleri',
      description: 'Estetik ve dayanıklı asma tavan çözümleri ile mekanlarınıza modern bir görünüm kazandırıyoruz. Gips karton, alüminyum ve diğer malzemeleri kullanarak profesyonel uygulamalar gerçekleştiriyoruz.',
      image: '/hero_asma_tavan.jpg',
      bgColor: 'from-blue-500 to-blue-600',
      textColor: 'text-blue-600',
    },
    {
      number: '02',
      icon: Package,
      title: 'Karo Pan Tavan',
      description: 'Farklı mekanlar için şık ve pratik karo pan uygulamaları sunuyoruz. Ofisler, hastaneler, okullar ve ticari alanlar için ideal çözümler sağlıyoruz.',
      image: '/karo_pan_tavan.jpg',
      bgColor: 'from-purple-500 to-purple-600',
      textColor: 'text-purple-600',
    },
    {
      number: '03',
      icon: Hammer,
      title: 'Alçı Pan Tavan',
      description: 'Modern ve fonksiyonel alçı pan tavan sistemleri ile yaşam alanlarınızı güzelleştiriyoruz. Işık tasarımı ve akustik özellikler ile konforlu mekanlar oluşturuyoruz.',
      image: '/alci_pan_tavan.jpg',
      bgColor: 'from-pink-500 to-pink-600',
      textColor: 'text-pink-600',
    },
    {
      number: '04',
      icon: Droplet,
      title: 'Su Tesisat İşleri',
      description: 'Sorunsuz ve güvenli su tesisat sistemleri ile yaşam ve iş alanlarınızda konfor sağlıyoruz. Bakım, onarım ve yeni tesisatlar konusunda deneyimli ekibimiz hazırdır.',
      image: '/hero_asma_tavan.jpg',
      bgColor: 'from-cyan-500 to-cyan-600',
      textColor: 'text-cyan-600',
    },
    {
      number: '05',
      icon: Wrench,
      title: 'Tadilat Hizmetleri',
      description: 'Genel tadilat işlerinde deneyimli ekibimiz, projelerinizi profesyonelce gerçekleştirir. Küçük onarımlardan büyük renovasyon projelerine kadar tüm işleri yürütüyoruz.',
      image: '/karo_pan_tavan.jpg',
      bgColor: 'from-orange-500 to-orange-600',
      textColor: 'text-orange-600',
    },
    {
      number: '06',
      icon: Package,
      title: 'İnşaat Malzemeleri',
      description: 'Kaliteli ve güvenilir inşaat malzemeleri temini ile projelerinizin her aşamasında yanınızdayız. Dayanıklı malzemelerle uzun ömürlü çözümler sağlıyoruz.',
      image: '/alci_pan_tavan.jpg',
      bgColor: 'from-green-500 to-green-600',
      textColor: 'text-green-600',
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-accent to-accent/80 text-accent-foreground py-20">
        <div className="container">
          <h1 className="text-5xl font-bold mb-4">Hizmetlerimiz</h1>
          <p className="text-xl opacity-90">Adana'da asma tavan ve iç mekan tasarımında sunduğumuz kapsamlı hizmetler</p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-gradient-to-b from-background to-muted">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <div key={index} className="group">
                  {/* Image Container */}
                  <div className="relative h-64 rounded-t-xl overflow-hidden mb-0">
                    <img
                      src={service.image}
                      alt={service.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition duration-300"
                    />
                    {/* Number Badge */}
                    <div className={`absolute top-4 right-4 bg-gradient-to-br ${service.bgColor} text-white w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg shadow-lg`}>
                      {service.number}
                    </div>
                    {/* Overlay */}
                    <div className="absolute inset-0 bg-black/30 group-hover:bg-black/50 transition duration-300"></div>
                  </div>

                  {/* Content Container */}
                  <div className={`bg-gradient-to-br ${service.bgColor} text-white rounded-b-xl p-8 hover:shadow-2xl transition-all duration-300`}>
                    {/* Icon */}
                    <div className="bg-white/20 w-14 h-14 rounded-lg flex items-center justify-center mb-4">
                      <Icon size={28} />
                    </div>

                    {/* Title and Description */}
                    <h3 className="text-2xl font-bold mb-3">{service.title}</h3>
                    <p className="text-white/90 mb-6 leading-relaxed text-sm">
                      {service.description}
                    </p>

                    {/* Link */}
                    <a
                      href="/iletisim"
                      className="inline-flex items-center gap-2 text-white font-semibold hover:gap-3 transition-all group/link bg-white/20 px-4 py-2 rounded-lg hover:bg-white/30"
                    >
                      <span>Teklif Alın</span>
                      <ArrowRight size={18} className="group-hover/link:translate-x-1 transition" />
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-accent text-accent-foreground">
        <div className="container text-center">
          <h2 className="text-4xl font-bold mb-6">Hizmetleriniz İçin Teklif Alın</h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Adana'da asma tavan ve iç mekan tasarımı hizmetleri için bize ulaşın. Deneyimli ekibimiz, projelerinizi profesyonelce gerçekleştirmek için hazır.
          </p>
          <a
            href="/iletisim"
            className="inline-block bg-accent-foreground text-accent px-8 py-4 rounded-lg font-bold hover:opacity-90 transition"
          >
            İletişim Sayfasına Git
          </a>
        </div>
      </section>
    </div>
  );
}
