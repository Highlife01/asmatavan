import { Hammer, Droplet, Wrench, Package, Lightbulb, ArrowRight } from 'lucide-react';

export default function Services() {
  const services = [
    {
      icon: Lightbulb,
      title: 'Asma Tavan Sistemleri',
      description: 'Estetik ve dayanıklı asma tavan çözümleri ile mekanlarınıza modern bir görünüm kazandırıyoruz.',
      color: 'from-blue-500 to-blue-600',
    },
    {
      icon: Package,
      title: 'Karo Pan Tavan',
      description: 'Farklı mekanlar için şık ve pratik karo pan uygulamaları sunuyoruz.',
      color: 'from-purple-500 to-purple-600',
    },
    {
      icon: Hammer,
      title: 'Alçı Pan Tavan',
      description: 'Modern ve fonksiyonel alçı pan tavan sistemleri ile yaşam alanlarınızı güzelleştiriyoruz.',
      color: 'from-pink-500 to-pink-600',
    },
    {
      icon: Droplet,
      title: 'Su Tesisat İşleri',
      description: 'Sorunsuz ve güvenli su tesisat sistemleri ile yaşam ve iş alanlarınızda konfor sağlıyoruz.',
      color: 'from-cyan-500 to-cyan-600',
    },
    {
      icon: Wrench,
      title: 'Tadilat Hizmetleri',
      description: 'Genel tadilat işlerinde deneyimli ekibimiz, projelerinizi profesyonelce gerçekleştirir.',
      color: 'from-orange-500 to-orange-600',
    },
    {
      icon: Package,
      title: 'İnşaat Malzemeleri',
      description: 'Kaliteli ve güvenilir inşaat malzemeleri temini ile projelerinizin her aşamasında yanınızdayız.',
      color: 'from-green-500 to-green-600',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-background to-muted">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            Hizmetlerimiz
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Adana'da asma tavan ve iç mekan tasarımında sunduğumuz kapsamlı ve profesyonel hizmetler
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={index}
                className="group bg-card border border-border rounded-xl p-8 hover:shadow-2xl transition-all duration-300 hover:border-accent/50 hover:-translate-y-2"
              >
                {/* Icon Background */}
                <div className={`bg-gradient-to-br ${service.color} w-16 h-16 rounded-lg flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="text-white" size={32} />
                </div>

                {/* Title and Description */}
                <h3 className="text-xl font-bold mb-3 text-foreground group-hover:text-accent transition">
                  {service.title}
                </h3>
                <p className="text-foreground/70 mb-6 leading-relaxed">
                  {service.description}
                </p>

                {/* Link */}
                <a
                  href="/iletisim"
                  className="inline-flex items-center gap-2 text-accent font-semibold hover:gap-3 transition-all group/link"
                >
                  <span>Detaylı Bilgi</span>
                  <ArrowRight size={18} className="group-hover/link:translate-x-1 transition" />
                </a>
              </div>
            );
          })}
        </div>

        <div className="text-center mt-16">
          <a
            href="/hizmetler"
            className="inline-flex items-center gap-2 bg-accent text-accent-foreground px-8 py-4 rounded-lg font-bold hover:bg-accent/90 transition group"
          >
            <span>Tüm Hizmetleri Gör</span>
            <ArrowRight size={20} className="group-hover:translate-x-1 transition" />
          </a>
        </div>
      </div>
    </section>
  );
}
