import { Star, Quote } from 'lucide-react';

export default function Testimonials() {
  const testimonials = [
    {
      name: 'Ayşe K.',
      location: 'Adana',
      text: 'Dems Mimarlık ile çalışmak çok keyifliydi. Asma tavan projem tam istediğim gibi oldu ve ekip gerçekten çok profesyoneldi.',
      rating: 5,
      image: '👩‍💼',
    },
    {
      name: 'Mehmet T.',
      location: 'Adana',
      text: 'Projeyi zamanında teslim ettiler ve kullanılan malzemelerin kalitesi gerçekten etkileyici. Kesinlikle tavsiye ederim.',
      rating: 5,
      image: '👨‍💼',
    },
    {
      name: 'Elif S.',
      location: 'Adana',
      text: 'Evimizin iç tasarımında bize harika fikirler sundular ve uygulama süreci çok sorunsuz geçti. Sonuçtan çok memnunuz.',
      rating: 5,
      image: '👩‍🦰',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-background to-muted">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            Müşteri Yorumları
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Müşterilerimizin bize duydukları güven ve memnuniyeti görmekten gurur duyuyoruz
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="group bg-card border border-border rounded-xl p-8 hover:shadow-xl transition-all duration-300 hover:border-accent/50 hover:-translate-y-2 relative overflow-hidden"
            >
              {/* Background decoration */}
              <div className="absolute top-0 right-0 opacity-10 group-hover:opacity-20 transition">
                <Quote size={80} className="text-accent" />
              </div>

              {/* Stars */}
              <div className="flex gap-1 mb-6 relative z-10">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star
                    key={i}
                    size={18}
                    className="fill-accent text-accent"
                  />
                ))}
              </div>

              {/* Quote */}
              <p className="text-foreground/80 mb-6 leading-relaxed italic relative z-10">
                "{testimonial.text}"
              </p>

              {/* Author */}
              <div className="border-t border-border pt-6 flex items-center gap-4 relative z-10">
                <div className="text-3xl">{testimonial.image}</div>
                <div>
                  <p className="font-bold text-foreground">{testimonial.name}</p>
                  <p className="text-sm text-foreground/60">{testimonial.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trust Badge */}
        <div className="mt-16 grid grid-cols-3 gap-8 text-center">
          <div className="bg-card border border-border rounded-lg p-6">
            <div className="text-3xl font-bold text-accent mb-2">500+</div>
            <p className="text-foreground/70">Memnun Müşteri</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-6">
            <div className="text-3xl font-bold text-accent mb-2">4.9★</div>
            <p className="text-foreground/70">Ortalama Puan</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-6">
            <div className="text-3xl font-bold text-accent mb-2">100%</div>
            <p className="text-foreground/70">Tavsiye Oranı</p>
          </div>
        </div>
      </div>
    </section>
  );
}
