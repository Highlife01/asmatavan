import { Phone, MessageCircle } from 'lucide-react';

export default function CTA() {
  return (
    <section className="py-20 bg-accent text-accent-foreground">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Hemen Teklif Alın
          </h2>
          <p className="text-lg mb-10 opacity-90">
            Adana'da asma tavan ve iç mekan tasarımı hizmetleri için bize ulaşın. Deneyimli ekibimiz, projelerinizi profesyonelce gerçekleştirmek için hazır.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:+905320550945"
              className="bg-accent-foreground text-accent px-8 py-4 rounded-lg font-bold hover:opacity-90 transition inline-flex items-center justify-center gap-2"
            >
              <Phone size={20} />
              Telefon Ara
            </a>
            <a
              href="https://wa.me/905320550945"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white/20 text-accent-foreground px-8 py-4 rounded-lg font-bold hover:bg-white/30 transition inline-flex items-center justify-center gap-2 border border-accent-foreground/50"
            >
              <MessageCircle size={20} />
              WhatsApp Gönder
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
