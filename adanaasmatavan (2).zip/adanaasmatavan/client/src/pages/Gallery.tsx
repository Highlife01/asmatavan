import { useState } from 'react';
import { X } from 'lucide-react';

export default function Gallery() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const galleryImages = [
    {
      id: 1,
      title: 'Modern Asma Tavan',
      category: 'Asma Tavan',
      image: '/hero_asma_tavan.jpg',
    },
    {
      id: 2,
      title: 'Karo Pan Tavan Uygulaması',
      category: 'Karo Pan',
      image: '/karo_pan_tavan.jpg',
    },
    {
      id: 3,
      title: 'Alçı Pan Tavan Tasarımı',
      category: 'Alçı Pan',
      image: '/alci_pan_tavan.jpg',
    },
    {
      id: 4,
      title: 'Ofis Asma Tavan',
      category: 'Asma Tavan',
      image: '/hero_asma_tavan.jpg',
    },
    {
      id: 5,
      title: 'Ticari Alan Karo Pan',
      category: 'Karo Pan',
      image: '/karo_pan_tavan.jpg',
    },
    {
      id: 6,
      title: 'Konut İç Mekan',
      category: 'Alçı Pan',
      image: '/alci_pan_tavan.jpg',
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-accent to-accent/80 text-accent-foreground py-20">
        <div className="container">
          <h1 className="text-5xl font-bold mb-4">Galerimiz</h1>
          <p className="text-xl opacity-90">Tamamlanan projelerimizden seçilmiş örnekler</p>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {galleryImages.map((item) => (
              <div
                key={item.id}
                className="group relative overflow-hidden rounded-lg cursor-pointer"
                onClick={() => setSelectedImage(item.image)}
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-64 object-cover group-hover:scale-110 transition duration-300"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                  <div className="text-center text-white">
                    <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                    <p className="text-sm opacity-90">{item.category}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div
          className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <div className="relative max-w-4xl w-full" onClick={(e) => e.stopPropagation()}>
            <img
              src={selectedImage}
              alt="Gallery"
              className="w-full h-auto rounded-lg"
            />
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-4 right-4 bg-white/20 hover:bg-white/40 text-white p-2 rounded-lg transition"
            >
              <X size={24} />
            </button>
          </div>
        </div>
      )}

      {/* CTA Section */}
      <section className="py-20 bg-muted">
        <div className="container text-center">
          <h2 className="text-4xl font-bold mb-6 text-foreground">Sizin Projeniz Burada Olabilir</h2>
          <p className="text-lg text-foreground/70 mb-8 max-w-2xl mx-auto">
            Adana'da asma tavan ve iç mekan tasarımı projeleriniz için bize ulaşın. Profesyonel ekibimiz, mekanlarınızı dönüştürmek için hazır.
          </p>
          <a
            href="/iletisim"
            className="inline-block bg-accent text-accent-foreground px-8 py-4 rounded-lg font-bold hover:bg-accent/90 transition"
          >
            Proje Başlatalım
          </a>
        </div>
      </section>
    </div>
  );
}
