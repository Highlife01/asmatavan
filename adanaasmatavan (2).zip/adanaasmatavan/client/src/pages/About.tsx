import { CheckCircle, Users, Award, Target } from 'lucide-react';

export default function AboutPage() {
  const values = [
    {
      icon: Target,
      title: 'Vizyonumuz',
      description: 'Adana\'da asma tavan ve iç mekan çözümleri denildiğinde akla gelen ilk firma olmak; estetik, konfor ve kaliteyi bir arada sunarak sektörde öncü ve güvenilir bir marka haline gelmek.',
    },
    {
      icon: Users,
      title: 'Misyonumuz',
      description: 'Müşterilerimizin yaşam ve çalışma alanlarını modern, estetik ve fonksiyonel hale getirmek için kaliteli malzeme ve profesyonel işçilikle hizmet vermek.',
    },
    {
      icon: Award,
      title: 'Değerlerimiz',
      description: 'Müşteri memnuniyeti, kaliteli işçilik, zamanında teslimat ve etik iş yapma ilkeleri üzerine kurulu hizmetler sunuyoruz.',
    },
  ];

  const achievements = [
    { number: '100+', label: 'Tamamlanan Proje' },
    { number: '20+', label: 'Yıllık Tecrübe' },
    { number: '4.9★', label: 'Müşteri Puanı' },
    { number: '500+', label: 'Memnun Müşteri' },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-accent to-accent/80 text-accent-foreground py-20">
        <div className="container">
          <h1 className="text-5xl font-bold mb-4">Hakkımızda</h1>
          <p className="text-xl opacity-90">Adana'da asma tavan ve iç mekan tasarımında 20 yılı aşkın deneyim</p>
        </div>
      </section>

      {/* About Content */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-4xl font-bold mb-6 text-foreground">Biz Kimiz?</h2>
              <p className="text-lg text-foreground/80 mb-4 leading-relaxed">
                Adana Asma Tavan olarak, 20 yılı aşkın süredir asma tavan ve iç mekan tasarımı alanında profesyonel hizmetler sunmaktayız. Karo pan, alçı pan tavan, su tesisat ve tadilat işlerinde kaliteli malzeme ve titiz işçilikle projelerinizi hayata geçiriyoruz.
              </p>
              <p className="text-lg text-foreground/80 mb-6 leading-relaxed">
                Müşteri memnuniyetini esas alan yaklaşımımızla, yaşam ve çalışma alanlarınıza değer katıyoruz. Deneyimli ekibimiz ve kaliteli malzeme anlayışımızla, müşterilerimizin beklentilerini karşılamanın ötesinde, mekânlarına değer katan tasarımlar ortaya koyuyoruz.
              </p>
              <div className="flex gap-4">
                <a
                  href="/iletisim"
                  className="bg-accent text-accent-foreground px-6 py-3 rounded-lg font-bold hover:bg-accent/90 transition"
                >
                  İletişime Geçin
                </a>
              </div>
            </div>
            <div className="rounded-lg overflow-hidden shadow-lg">
              <img
                src="/hero_asma_tavan.jpg"
                alt="Adana Asma Tavan"
                className="w-full h-96 object-cover"
              />
            </div>
          </div>

          {/* Achievements */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16 py-12 border-y border-border">
            {achievements.map((achievement, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-accent mb-2">{achievement.number}</div>
                <p className="text-foreground/70">{achievement.label}</p>
              </div>
            ))}
          </div>

          {/* Vision, Mission, Values */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <div key={index} className="bg-card border border-border rounded-lg p-8">
                  <div className="bg-accent/10 w-16 h-16 rounded-lg flex items-center justify-center mb-4">
                    <Icon className="text-accent" size={32} />
                  </div>
                  <h3 className="text-2xl font-bold mb-3 text-foreground">{value.title}</h3>
                  <p className="text-foreground/70 leading-relaxed">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-muted">
        <div className="container">
          <h2 className="text-4xl font-bold mb-12 text-center text-foreground">Neden Bizi Seçmelisiniz?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                title: 'Profesyonel İşçilik',
                description: 'Deneyimli ekibimiz, projelerinizi özenle ve titizlikle tamamlayarak uzun ömürlü ve kaliteli sonuçlar sunar.',
              },
              {
                title: 'Kaliteli Malzeme',
                description: 'Kullanılan malzemeler, dayanıklılık ve estetik kriterleri göz önünde bulundurularak seçilir.',
              },
              {
                title: 'Zamanında Teslimat',
                description: 'Planlı ve organize çalışma süreci ile projeler zamanında tamamlanır.',
              },
              {
                title: 'Müşteri Memnuniyeti',
                description: 'Her aşamada müşteri memnuniyeti ön planda tutularak, en iyi hizmeti sunuyoruz.',
              },
            ].map((item, index) => (
              <div key={index} className="bg-card border border-border rounded-lg p-8 hover:shadow-lg transition">
                <div className="flex items-start gap-4">
                  <CheckCircle className="text-accent flex-shrink-0 mt-1" size={24} />
                  <div>
                    <h3 className="font-bold text-lg mb-2 text-foreground">{item.title}</h3>
                    <p className="text-foreground/70">{item.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
