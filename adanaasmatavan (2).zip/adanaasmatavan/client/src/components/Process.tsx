import { Search, Pencil, Wrench } from 'lucide-react';

export default function Process() {
  const steps = [
    {
      number: '01',
      icon: Search,
      title: 'İhtiyaç Analizi',
      description: 'Müşterimizin talepleri ve mekanın özellikleri detaylı olarak incelenir, en uygun tasarım ve çözüm planlanır.',
      color: 'from-blue-500 to-blue-600',
    },
    {
      number: '02',
      icon: Pencil,
      title: 'Proje ve Tasarım',
      description: 'Proje aşamasında estetik, fonksiyonellik ve bütçe göz önünde bulundurularak kapsamlı bir planlama yapılır.',
      color: 'from-purple-500 to-purple-600',
    },
    {
      number: '03',
      icon: Wrench,
      title: 'Uygulama ve Teslim',
      description: 'Deneyimli ekibimizle kaliteli malzeme ve işçilik kullanılarak proje tamamlanır, zamanında ve eksiksiz olarak teslim edilir.',
      color: 'from-orange-500 to-orange-600',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-muted to-background">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            Çalışma Süreci
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Projelerimizi titizlikle planlıyor ve her aşamada kaliteyi ön planda tutuyoruz
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {/* Connection Line */}
          <div className="hidden md:block absolute top-32 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-orange-500 -z-10"></div>

          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={index} className="relative group">
                {/* Card */}
                <div className="bg-card border border-border rounded-xl p-8 h-full hover:shadow-xl transition-all duration-300 hover:border-accent/50">
                  {/* Step Number Circle */}
                  <div className={`absolute -top-6 left-8 w-12 h-12 rounded-full bg-gradient-to-br ${step.color} flex items-center justify-center text-white font-bold text-lg shadow-lg`}>
                    {step.number}
                  </div>

                  {/* Icon */}
                  <div className={`bg-gradient-to-br ${step.color} w-16 h-16 rounded-lg flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                    <Icon className="text-white" size={32} />
                  </div>

                  {/* Title and Description */}
                  <h3 className="text-2xl font-bold mb-3 text-foreground">{step.title}</h3>
                  <p className="text-foreground/70 leading-relaxed">{step.description}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <p className="text-lg text-foreground/70 mb-6">
            Projeleriniz için bu süreci başlatmaya hazır mısınız?
          </p>
          <a
            href="/iletisim"
            className="inline-block bg-accent text-accent-foreground px-8 py-4 rounded-lg font-bold hover:bg-accent/90 transition"
          >
            Hemen Başlayalım
          </a>
        </div>
      </div>
    </section>
  );
}
