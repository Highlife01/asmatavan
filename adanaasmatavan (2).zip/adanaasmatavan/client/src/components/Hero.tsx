import { ArrowRight, CheckCircle } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background with overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center z-0"
        style={{
          backgroundImage: 'url(/hero_asma_tavan.jpg)',
          backgroundAttachment: 'fixed',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/40"></div>
      </div>

      {/* Content */}
      <div className="container relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-white">
            <div className="inline-block bg-accent/20 text-accent px-4 py-2 rounded-full mb-6 border border-accent/50">
              <span className="text-sm font-semibold">20 Yıllık Deneyim</span>
            </div>

            <h1 className="text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Mekanlarınıza Estetik ve Fonksiyonellik Katıyoruz
            </h1>

            <p className="text-xl text-gray-200 mb-8 leading-relaxed max-w-lg">
              Adana'da asma tavan, karo pan, alçı pan ve iç mekan tasarımında profesyonel çözümler. Kaliteli malzeme ve titiz işçilikle projelerinizi hayata geçiriyoruz.
            </p>

            {/* Features */}
            <div className="space-y-3 mb-8">
              <div className="flex items-center gap-3">
                <CheckCircle className="text-accent flex-shrink-0" size={20} />
                <span className="text-gray-100">100+ Tamamlanan Proje</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="text-accent flex-shrink-0" size={20} />
                <span className="text-gray-100">Zamanında Teslimat Garantisi</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="text-accent flex-shrink-0" size={20} />
                <span className="text-gray-100">4.9★ Müşteri Memnuniyeti</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="https://wa.me/905320550945"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-4 rounded-lg font-bold transition inline-flex items-center justify-center gap-2 group"
              >
                <span>WhatsApp Hattımız</span>
                <ArrowRight size={20} className="group-hover:translate-x-1 transition" />
              </a>
              <a
                href="/iletisim"
                className="bg-white/20 hover:bg-white/30 text-white px-8 py-4 rounded-lg font-bold transition border border-white/50 inline-flex items-center justify-center gap-2"
              >
                <span>Teklif Alın</span>
              </a>
            </div>
          </div>

          {/* Right Stats */}
          <div className="hidden lg:grid grid-cols-2 gap-6">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-8 text-white hover:bg-white/20 transition">
              <div className="text-4xl font-bold text-accent mb-2">100+</div>
              <p className="text-gray-200">Tamamlanan Proje</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-8 text-white hover:bg-white/20 transition">
              <div className="text-4xl font-bold text-accent mb-2">20+</div>
              <p className="text-gray-200">Yıllık Tecrübe</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-8 text-white hover:bg-white/20 transition">
              <div className="text-4xl font-bold text-accent mb-2">4.9★</div>
              <p className="text-gray-200">Müşteri Puanı</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-8 text-white hover:bg-white/20 transition">
              <div className="text-4xl font-bold text-accent mb-2">500+</div>
              <p className="text-gray-200">Memnun Müşteri</p>
            </div>
          </div>
        </div>

        {/* Mobile Stats */}
        <div className="grid grid-cols-2 lg:hidden gap-4 mt-12">
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-6 text-white text-center">
            <div className="text-3xl font-bold text-accent mb-1">100+</div>
            <p className="text-sm text-gray-200">Proje</p>
          </div>
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-6 text-white text-center">
            <div className="text-3xl font-bold text-accent mb-1">20+</div>
            <p className="text-sm text-gray-200">Tecrübe</p>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 animate-bounce">
        <div className="text-white text-center">
          <svg
            className="w-6 h-6 mx-auto"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 14l-7 7m0 0l-7-7m7 7V3"
            />
          </svg>
        </div>
      </div>
    </section>
  );
}
