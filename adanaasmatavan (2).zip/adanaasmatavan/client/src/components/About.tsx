import { CheckCircle } from 'lucide-react';

export default function About() {
  const values = [
    {
      title: 'Profesyonel İşçilik',
      description: 'Deneyimli ekibimiz, projelerinizi özenle ve titizlikle tamamlayarak uzun ömürlü ve kaliteli sonuçlar sunar.',
    },
    {
      title: 'Kaliteli Malzeme',
      description: 'Kullanılan malzemeler, dayanıklılık ve estetik kriterleri göz önünde bulundurularak seçilir.',
    },
    {
      title: 'Zamanında Teslimat',
      description: 'Planlı ve organize çalışma süreci ile projeler zamanında tamamlanır, müşterilerimizin programı aksatılmaz.',
    },
    {
      title: 'Estetik ve Fonksiyonellik',
      description: 'Tasarım anlayışımız, mekanlarınıza hem görsel güzellik hem de pratik kullanım avantajı kazandırır.',
    },
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
          {/* Left Content */}
          <div>
            <h2 className="text-4xl font-bold mb-6 text-foreground">
              Biz Kimiz?
            </h2>
            <p className="text-lg text-foreground/80 mb-4 leading-relaxed">
              Adana Asma Tavan olarak, 20 yılı aşkın süredir asma tavan ve iç mekan tasarımı alanında profesyonel hizmetler sunmaktayız.
            </p>
            <p className="text-lg text-foreground/80 mb-6 leading-relaxed">
              Karo pan, alçı pan tavan, su tesisat ve tadilat işlerinde kaliteli malzeme ve titiz işçilikle projelerinizi hayata geçiriyoruz. Müşteri memnuniyetini esas alan yaklaşımımızla, yaşam ve çalışma alanlarınıza değer katıyoruz.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-6">
              <div className="bg-muted p-4 rounded-lg">
                <div className="text-3xl font-bold text-accent mb-2">100+</div>
                <p className="text-sm text-foreground/70">Tamamlanan Proje</p>
              </div>
              <div className="bg-muted p-4 rounded-lg">
                <div className="text-3xl font-bold text-accent mb-2">4.9★</div>
                <p className="text-sm text-foreground/70">Müşteri Puanı</p>
              </div>
            </div>
          </div>

          {/* Right Image */}
          <div className="rounded-lg overflow-hidden shadow-lg">
            <img
              src="/alci_pan_tavan.jpg"
              alt="Asma Tavan Projesi"
              className="w-full h-96 object-cover"
            />
          </div>
        </div>

        {/* Values Grid */}
        <div>
          <h3 className="text-3xl font-bold mb-12 text-center text-foreground">
            Neden Biz?
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-card border border-border rounded-lg p-6 hover:shadow-lg transition">
                <div className="flex items-start gap-4">
                  <CheckCircle className="text-accent flex-shrink-0 mt-1" size={24} />
                  <div>
                    <h4 className="font-bold text-lg mb-2 text-foreground">{value.title}</h4>
                    <p className="text-foreground/70">{value.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
