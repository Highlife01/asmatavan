import { useState } from 'react';
import { Menu, X, Phone, Mail } from 'lucide-react';
import { Link } from 'wouter';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen(!isOpen);
  const phone = "05320550945";
  const email = "cebrailkara@outlook.com";

  const navItems = [
    { label: 'Anasayfa', href: '/' },
    { label: 'Hizmetlerimiz', href: '/hizmetler' },
    { label: 'Galerimiz', href: '/galeri' },
    { label: 'Hakkımızda', href: '/hakkimizda' },
    { label: 'İletişim', href: '/iletisim' },
  ];

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      {/* Top Bar */}
      <div className="bg-accent text-accent-foreground py-2">
        <div className="container flex justify-between items-center text-sm">
          <div className="flex gap-4">
            <a href={`tel:+90${phone}`} className="flex items-center gap-2 hover:opacity-80 transition">
              <Phone size={16} />
              <span>{phone}</span>
            </a>
            <a href={`mailto:${email}`} className="flex items-center gap-2 hover:opacity-80 transition">
              <Mail size={16} />
              <span>{email}</span>
            </a>
          </div>
          <div className="flex gap-3">
            <a href="#" className="hover:opacity-80 transition">Facebook</a>
            <a href="#" className="hover:opacity-80 transition">Instagram</a>
            <a href="#" className="hover:opacity-80 transition">WhatsApp</a>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="container flex justify-between items-center py-4">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center text-accent-foreground font-bold text-lg">
            A
          </div>
          <span className="font-bold text-xl text-foreground hidden sm:inline">Adana Asma Tavan</span>
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex gap-8">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <a className="text-foreground hover:text-accent transition font-medium">
                {item.label}
              </a>
            </Link>
          ))}
        </div>

        {/* CTA Button */}
        <a
          href={`https://wa.me/90${phone}`}
          target="_blank"
          rel="noopener noreferrer"
          className="hidden sm:inline-block bg-accent text-accent-foreground px-6 py-2 rounded-lg font-semibold hover:bg-accent/90 transition"
        >
          WhatsApp Hattımız
        </a>

        {/* Mobile Menu Button */}
        <button
          onClick={toggleMenu}
          className="md:hidden p-2 hover:bg-muted rounded-lg transition"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-border">
          <div className="container py-4 flex flex-col gap-4">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <a
                  className="text-foreground hover:text-accent transition font-medium block"
                  onClick={() => setIsOpen(false)}
                >
                  {item.label}
                </a>
              </Link>
            ))}
            <a
              href={`https://wa.me/90${phone}`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-accent text-accent-foreground px-6 py-2 rounded-lg font-semibold hover:bg-accent/90 transition text-center"
            >
              WhatsApp Hattımız
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}
