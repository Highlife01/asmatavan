import { Phone, Mail, MapPin, Facebook, Instagram, MessageCircle } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-foreground text-background">
      {/* Main Footer */}
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About Section */}
          <div>
            <h3 className="text-lg font-bold mb-4">Adana Asma Tavan</h3>
            <p className="text-sm opacity-90">
              20 yılı aşkın deneyimle Adana'da asma tavan ve iç mekan tasarımında profesyonel çözümler sunuyoruz.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold mb-4">Hızlı Linkler</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="/" className="hover:text-accent transition">Anasayfa</a></li>
              <li><a href="/hizmetler" className="hover:text-accent transition">Hizmetlerimiz</a></li>
              <li><a href="/galeri" className="hover:text-accent transition">Galerimiz</a></li>
              <li><a href="/hakkimizda" className="hover:text-accent transition">Hakkımızda</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-bold mb-4">Hizmetler</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-accent transition">Asma Tavan</a></li>
              <li><a href="#" className="hover:text-accent transition">Karo Pan</a></li>
              <li><a href="#" className="hover:text-accent transition">Alçı Pan</a></li>
              <li><a href="#" className="hover:text-accent transition">Su Tesisat</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold mb-4">İletişim</h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-2">
                <Phone size={16} />
                <a href="tel:+905320550945" className="hover:text-accent transition">0532 055 0945</a>
              </div>
              <div className="flex items-center gap-2">
                <Mail size={16} />
                <a href="mailto:cebrailkara@outlook.com" className="hover:text-accent transition">cebrailkara@outlook.com</a>
              </div>
              <div className="flex items-center gap-2">
                <MapPin size={16} />
                <span>Adana, Türkiye</span>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-background/20 my-8"></div>

        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm opacity-75">
            © {currentYear} Adana Asma Tavan. Tüm hakları saklıdır.
          </p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-accent transition" title="Facebook">
              <Facebook size={20} />
            </a>
            <a href="#" className="hover:text-accent transition" title="Instagram">
              <Instagram size={20} />
            </a>
            <a href="https://wa.me/905320550945" target="_blank" rel="noopener noreferrer" className="hover:text-accent transition" title="WhatsApp">
              <MessageCircle size={20} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
